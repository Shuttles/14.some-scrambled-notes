#include<stdlib.h>
#include<stdio.h>
#ifndef LISTS_H
#define LISTS_H
typedef enum { ATOM, LIST }tags;
typedef enum { TEC, STU }ident;
typedef struct atomitem
{
	ident ide;
	char name[100000];
	union MyUnion
	{
		char hiszc[100000];
		int hisclass;
	};
}ATOMITEM;
typedef struct gnode
{
	tags tag;
	union
	{
		ATOMITEM    atom;
		struct gnode  *hp;
	};
	struct gnode    *tp;
}GNODE;
typedef struct glist
{
	GNODE *head;
	int teacherNum;
}GLIST;
GNODE *moveGnode(GNODE *from, int indexof)
{
	void moveOver();
	GNODE *read = from;
	for (int i = 1; i < indexof; i++)
	{
		if (read == NULL)
		{
			atexit(moveOver);
			exit(0);
		}
		read = read->tp;
	}
	return read;
}
GNODE *moveEndGnode(GNODE *from)
{
	GNODE *read = from;
	while (read->tp != NULL)
	{
		read = read->tp;
	}
	return read;
}
void showOneGlist(GNODE *G)
{
	if (G->atom.ide == TEC)
	{
		printf("��ʦ���� �� %s\n", G->atom.name);
		printf("��ʦְ�� �� %s\n", G->atom.hiszc);
	}
	else
	{
		printf("���� �� %s\n", G->atom.name);
		printf("�༶ �� %d\n", G->atom.hisclass);
	}
}
void insertStudentGlist(GLIST *G, ATOMITEM In, int teacherNum, int gStudentNum, int position)
{
	GNODE *read, *read2, *read3;
	read = moveGnode(G->head, teacherNum);
	read2 = moveGnode(read->hp, gStudentNum + 1);
	read3 = moveGnode(read2->hp, position);
	GNODE *newStudent, *id;
	newStudent = (GNODE *)malloc(sizeof(GNODE));
	id = (GNODE *)malloc(sizeof(GNODE));
	id->tag = ATOM;
	id->atom.ide = STU;
	id->atom = In;
	id->tp = NULL;
	newStudent->tag = LIST;
	newStudent->tp = read3->tp;
	newStudent->hp = id;
	read3 = newStudent;
}
void insertGstudentGlist(GLIST *G, ATOMITEM In, int teacherNum, int position)
{
	GNODE *read, *read2;
	read = moveGnode(G->head, teacherNum);
	read2 = moveGnode(read->hp, position);
	GNODE *newStudent, *id;
	newStudent = (GNODE *)malloc(sizeof(GNODE));
	id = (GNODE *)malloc(sizeof(GNODE));
	id->tag = ATOM;
	id->atom.ide = STU;
	id->atom = In;
	id->tp = NULL;
	newStudent->tag = LIST;
	newStudent->tp = read2
		->tp;
	newStudent->hp = id;
	read2 = newStudent;
}
void deleteStudentGlist(GLIST *G, int teacherNum, int gStudentNum, int position)
{
	GNODE *read, *read2, *read3, *del;
	read = moveGnode(G->head, teacherNum);
	read2 = moveGnode(read->hp, gStudentNum + 1);
	read3 = moveGnode(read2->hp, position);
	del = read3->tp;
	read3->tp = read3->tp->tp;
	free(del);
}
void deleteGstudentGlist(GLIST *G, int teacherNum, int position)
{
	GNODE *read, *read2, *del;
	read = moveGnode(G->head, teacherNum);
	read2 = moveGnode(read->hp, position);
	del = read2->tp;
	read2->tp = read2->tp->tp;
	free(del);
}
void inquiryTeacherGlist(GLIST *G, int indexof)
{
	GNODE *read, *read2, *read3, *read4;
	int gStuNum = 0, stuNum = 0;;
	read = moveGnode(G->head, indexof);
	read2 = read->hp;
	printf("------------------------\n");
	showOneGlist(read2);
	printf("------------\n");
	if (read2->tp != NULL)
	{
		read2 = read2->tp;
		printf("�����о��� :\n");
		while (read2)
		{
			read3 = read2->hp;
			showOneGlist(read3);
			gStuNum += 1;
			if (read3->tp != NULL)
			{
				read3 = read3->tp;
				printf("���������� :\n");
				while (read3)
				{
					read4 = read3->hp;
					showOneGlist(read2);
					stuNum += 1;
					read3 = read3->tp;
				}
			}
			read2 = read2->tp;
		}
	}
	printf("�����о���%d��������������%d��\n", gStuNum, stuNum);
}
void inquiryGstudentGlist(GLIST *G, int teacherNum, int indexof)
{
	GNODE *read, *read2, *read3;
	read = moveGnode(G->head, teacherNum)->tp;
	read = moveGnode(read, indexof + 1);
	read2 = read->hp;
	showOneGlist(read2);
	if (read2->tp != NULL)
	{
		read2 = read2->tp;

		printf("���������� :\n");
		while (read2)
		{
			read3 = read2->hp;
			showOneGlist(read3);
		}
	}
}
void inquiryStudentGlist(GLIST *G, int teacherNum, int GstudentNum, int indexof)
{
	GNODE *read, *read2;
	read = moveGnode(G->head, teacherNum);
	read = moveGnode(read->hp, GstudentNum + 1);
	read = moveGnode(read->hp, indexof + 1);
	read2 = read->tp;
	showOneGlist(read2);
}
void iniGlist(GLIST *G)
{
	G->head = NULL;
	G->teacherNum = 0;
}
void addTeacherGlist(GLIST *G)
{
	GNODE *id;
	id = (GNODE *)malloc(sizeof(GNODE));
	id->tag = ATOM;
	id->atom.ide = TEC;
	id->tp = NULL;
	printf("�����뵼ʦ����\n");
	scanf("%s", id->atom.name);
	printf("�����뵼ʦְ��\n");
	scanf("%s", id->atom.hiszc);
	GNODE *newTeacher;
	newTeacher = (GNODE *)malloc(sizeof(GNODE));
	newTeacher->tag = LIST;
	newTeacher->hp = id;
	newTeacher->tp = NULL;
	if (G->teacherNum == 0)
	{
		G->head = newTeacher;
	}
	else
	{
		GNODE *read;
		read = moveEndGnode(G->head);
		read->tp = newTeacher;
	}
	G->teacherNum++;
}
void addGstudentGlist(GLIST *G)
{
	int inTeacher;
	printf("��ѡ�񼸺ŵ�ʦ");
	scanf(" %d", &inTeacher);
	GNODE *read;
	read = moveGnode(G->head, inTeacher);
	GNODE *read2;
	read2 = moveEndGnode(read->hp);
	GNODE *newGstudent, *id;
	newGstudent = (GNODE *)malloc(sizeof(GNODE));
	id = (GNODE *)malloc(sizeof(GNODE));
	id->tag = ATOM;
	id->atom.ide = STU;
	printf("������ѧ������\n");
	scanf("%s", id->atom.name);
	printf("������༶\n");
	scanf("%d", &id->atom.hisclass);
	id->tp = NULL;
	newGstudent->tag = LIST;
	newGstudent->tp = NULL;
	newGstudent->hp = id;
	read2->tp = newGstudent;
}
void addStudentGlist(GLIST *G)
{
	int inTeacher, inGstudent;
	printf("��ѡ�񼸺ŵ�ʦ\n");
	scanf(" %d", &inTeacher);
	printf("��ѡ�񼸺��о���\n");
	scanf(" %d", &inGstudent);
	GNODE *read;
	read = moveGnode(G->head, inTeacher);
	GNODE *read2;
	read2 = moveGnode(read->hp, inGstudent + 1);
	GNODE *read3;
	read3 = moveEndGnode(read2->hp);
	GNODE *newStudent, *id;
	newStudent = (GNODE *)malloc(sizeof(GNODE));
	id = (GNODE *)malloc(sizeof(GNODE));
	id->tag = ATOM;
	id->atom.ide = STU;
	printf("������ѧ������\n");
	scanf("%s", id->atom.name);
	printf("������༶\n");
	scanf("%d", &id->atom.hisclass);
	id->tp = NULL;
	newStudent->tag = LIST;
	newStudent->tp = NULL;
	newStudent->hp = id;
	read3->tp = newStudent;
}
void showGlist(GLIST *G)
{
	if (G->teacherNum == 0)
		printf("�ձ�");
	else
	{
		for (int i = 1; i <= G->teacherNum; i++)
		{
			inquiryTeacherGlist(G, i);
		}
	}
}
void moveOver()
{
	printf("�ƶ�Խ��");
	system("pause");
}
#endif // !1