#include<stdlib.h>
#include<stdio.h>
#include<stdbool.h>
#pragma once
#ifndef LINE
#define	LINE
typedef struct items2
{
	char F;
	int code;
}ITEM2;
typedef struct node
{
	struct node *prior;
	struct node *next;
	ITEM2 item;
}NODE;
typedef struct list
{
	NODE *first;
	NODE *last;
	int listSize;
}LIST2;
void iniList2(LIST2 *L)
{
	L->first = NULL;
	L->last = NULL;
	L->listSize = 0;
}
bool emptList2(LIST2 *L)
{
	if (L->listSize == 0)return 1;
	else return 0;
}
int sizeList2(LIST2 *L)
{
	return L->listSize;
}
void addList2(LIST2*L, ITEM2 IN)
{
	NODE *evt;
	evt = (NODE *)malloc(sizeof(NODE));
	evt->item = IN;
	if (L->listSize == 0)
	{
		evt->prior = NULL;
		evt->next = NULL;
		L->first = evt;
		L->last = evt;
	}
	else
	{
		evt->prior = L->last;
		evt->next = NULL;
		L->last->next = evt;
		L->last = evt;
	}
	L->listSize++;
}
void insertList2(LIST2 *L, ITEM2 IN, int indexof)
{
	if (indexof<1 || indexof>L->listSize + 1)
	{
		printf("�޴���Ŀ\n");
		return;
	}
	else if (indexof == L->listSize + 1)
	{
		addList2(L, IN);
		return;
	}
	else if (indexof == 1)
	{
		NODE *evt;
		evt = (NODE *)malloc(sizeof(NODE));
		evt->item = IN;
		evt->prior = NULL;
		evt->next = L->first;
		L->first = evt;
		L->listSize++;
	}
	else
	{
		NODE *read;
		read = L->first;
		for (int i = 1; i < L->listSize - 1; i++)
		{
			read = read->next;
		}
		NODE *evt;
		evt = (NODE *)malloc(sizeof(NODE));
		evt->item = IN;
		evt->prior = read;
		evt->next = read->next;
		read->next->prior = evt;
		read->next = evt;
		L->listSize++;
	}
}
void deleteList2(LIST2 *L, int indexof)
{
	void deleteLastList2(LIST2 *L);
	if (indexof<1||indexof>L->listSize)
	{
		printf("�޴���Ŀ,�޷�ɾ��\n");
		return;
	}
	else if (indexof == L->listSize)
	{
		deleteLastList2(L);
		return;
	}
	else if (indexof == 1)
	{
		NODE *read;
		read = L->first;
		read->next->prior = NULL;
		L->first = read->next;
		free(read);
		L->listSize--;
		return;
	}
	else
	{
		NODE *read;
		read = L->first;
		for (int i = 1; i < indexof; i++)
		{
			read = read->next;
		}
		read->prior->next = read->next;
		read->next->prior = read->prior;
		free(read);
		L->listSize--;
	}
}
void deleteLastList2(LIST2 *L)
{
	if (L->listSize == 0)
	{
		printf("������,�޷�ɾ��\n");
		return;
	}
	else if (L->listSize == 1)
	{
		free(L->first);
		L->first = NULL;
		L->last = NULL;
		L->listSize = 0;
	}
	else
	{
		NODE *read;
		read = L->last;
		read->prior->next = NULL;
		L->last = read->prior;
		free(read);
		L->listSize--;
	}
}
ITEM2 item2InList2(LIST2 *L, int indexof)
{
	if (indexof<1 || indexof>L->listSize)
	{
		printf("�޴���Ŀ");
		system("pause");
		exit();
	}
	NODE *read;
	read = L->first;
	for (int i = 1; i < indexof; i++)
	{
		read = read->next;
	}
	return read->item;
}
ITEM2 * item2PtrList2(LIST2 *L, int indexof)
{
	if (indexof<1 || indexof>L->listSize)
	{
		printf("�޴���Ŀ");
		system("pause");
		exit(0);
	}
	NODE *read;
	read = L->first;
	for (int i = 1; i < indexof; i++)
	{
		read = read->next;
	}
	return &read->item;
}
void reviseList2(LIST2 *L, int indexof, ITEM2 IN)
{

	if (indexof<1 || indexof>L->listSize)
	{
		printf("�޴���Ŀ");
		system("pause");
		exit(0);
	}
	NODE *read;
	read = L->first;
	for (int i = 1; i < indexof; i++)
	{
		read = read->next;
	}
	read->item = IN;
}
void moveList2(LIST2 *L, int from, int to)
{
	if (from > L->listSize || from < 0)
	{
		printf("�޴���Ŀ");
		return;
	}
	if (from > L->listSize || from < 0)
	{
		printf("�޴���Ŀ");
		return;
	}
	if (from == to)return;
	insertList2(L, itemInList2(L, from), to);
	if (from > to)
	{
		deleteList2(L, from + 1);
	}
	else
	{
		deleteList2(L, from);
	}
}
void sortList2(LIST2 *L, bool(*sortMethod)(ITEM2 readItem, ITEM2 sortItem))
{
	NODE *read;
	NODE *sort;
	read = L->first;
	int readNum;
	readNum = 1;
	while (read)
	{
		sort = L->first;
		int sortNum;
		sortNum = 1;
		while (sort != read)
		{
			if (sortMethod(read->item, sort->item))
			{
				insertList2(L, read->item, sortNum);
				readNum++;
				read = read->next;
				deleteList2(L, readNum);
				read = read->prior;
				readNum--;
				break;
			}
			sort = sort->next;
			sortNum++;
		}
		read = read->next;
		readNum++;
	}
}
void closeList2(LIST2 *L)
{
	NODE *read;
	read = L->first;
	for (int i = 1; i < L->listSize; i++)
	{
		read = read->next;
		free(read->prior);
	}
	free(read);
	L->first = NULL;
	L->last = NULL;
	L->listSize = 0;
}
#endif