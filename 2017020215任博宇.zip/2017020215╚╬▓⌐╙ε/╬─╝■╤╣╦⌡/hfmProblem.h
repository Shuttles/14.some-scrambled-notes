#pragma once
#include"˫������.h"
bool sortWeight(ITEM read, ITEM sort)
{
	if (read.weight> sort.weight)return 1;
	else return 0;
}
void travelBackHtree(HTREE *H, void(*travelMethod)(HTREE *HT,char *positionH),char *position)
{
	if (H->left != NULL)
	{
		travelBackHtree(H->left, travelMethod,position);
	}
	if (H->right != NULL)
	{
		travelBackHtree(H->right, travelMethod,position);
	}
	travelMethod(H,position);
}
void travelPrintf(HTREE *H,char *position)
{
	if (H->item.F != '0')
	{
		FILE *write;
		write = fopen(position, "a");
		putc(H->item.F, write);
		fclose(write);
	}
}
void findHfmProblem(LIST *L,char find)
{
	bool finded=0;
	for (int i = 1; i <= L->listSize; i++)
	{
		if (itemInList(L, i).hfm->item.F == find)
		{
			itemPtrList(L, i)->weight += 1;
			finded = 1;
			break;
		}
	}
	if (finded == 0)
	{
		ITEM newItem;
		newItem.hfm = (HTREE *)malloc(sizeof(HTREE));
		newItem.weight = 1;
		HITEM newHItem;
		newHItem.F = find;
		iniHtree(newItem.hfm, newHItem);
		addList(L, newItem);
	}
}
void iniHfmProblem(LIST *hfm)
{
	iniList(hfm);
	
}
void readHfmProblem(LIST *L, char *position)
{
	FILE *read;
	read = fopen(position, "r");
	char readChar;
	while ((readChar = getc(read)) != EOF)
	{
		findHfmProblem(L, readChar);
	}
	sortList(L, sortWeight);
}
void combineHfmProblem(LIST *L)
{
	while (L->listSize != 1)
	{
		ITEM newNode;
		newNode.hfm = combineNewHtree(itemPtrList(L, L->listSize - 1)->hfm, itemPtrList(L, L->listSize)->hfm);
		newNode.weight = itemPtrList(L, L->listSize - 1)->weight + itemPtrList(L, L->listSize)->weight;
 		deleteLastList(L);
		deleteLastList(L);
		addList(L, newNode);
	}
}
void printfHfmProblem(LIST *L,char *position)
{
	travelBackHtree(L->first->item.hfm,travelPrintf, position);
}
void txtToTree(char *from )
{
	LIST hfm;
	iniHfmProblem(&hfm);
	char position[20] = { "./Tree.dat" };
	readHfmProblem(&hfm, from);
	combineHfmProblem(&hfm);
	printfHfmProblem(&hfm, position);
}
void treeToCode(char *from)
{
	char position[20] = { "./Code.dat" };
	FILE *read;
	FILE *write;
	read = fopen(from, "r");
	write = fopen(position, "w");
	int readNum = 0;
	char readChar;
	while ((readChar = getc(read)) != EOF)
	{
		readNum++;
		putc(readChar, write);
		for (int i = 1; i < readNum; i++)
		{
			putc('1', write);
		}
		putc('0', write);
		putc('\n', write);
	}
	fclose(read);
	fclose(write);
}
HTREE * codeToTree(char *from)
{
	HTREE *returnTree;
	returnTree = (HTREE *)malloc(sizeof(HTREE));
	HTREE *readTree;
	readTree = returnTree;
	FILE *read;
	read = fopen(from, "r");
	char readChar;
	readChar = getc(read);
	returnTree->item.F = '0';
	returnTree->left = (HTREE *)malloc(sizeof(HTREE));
	returnTree->left->left = NULL;
	returnTree->left->right = NULL;
	returnTree->left->item.F = readChar;
	returnTree->right = NULL;
	while ((readChar = getc(read)) != '\n');
	while ((readChar = getc(read)) != EOF)
	{
		HTREE *newTree;
		newTree = (HTREE *)malloc(sizeof(HTREE));
		newTree->left = NULL;
		newTree->right = NULL;
		newTree->item.F = readChar;
		HTREE *newTreeup;
		newTreeup = (HTREE *)malloc(sizeof(HTREE));
		newTreeup->left = newTree;
		newTreeup->right = NULL;
		newTreeup->item.F = '0';
		readTree->right = newTreeup;
		readTree = readTree->right;
		while ((readChar = getc(read)) != '\n');
	}
	fclose(read);
	return returnTree;
}
void treeCompress(char *from,HTREE *codeTree)
{
	HTREE *readTree;
	char position[20] = { "./compress.dat" };
	FILE *read;
	FILE *write;
	read = fopen(from, "r");
	write = fopen(position, "w");
	char readChar;
	while ((readChar = getc(read)) != EOF)
	{
		readTree = codeTree;
		int readNum=0;
		while (readTree->left->item.F != readChar)
		{
			readTree = readTree->right;
			readNum++;
		}
		for (int i = 1; i <= readNum; i++)
		{
			putc('1', write);
		}
		putc('0', write);
	}
	fclose(read);
	fclose(write);
}
void treeDecompress(char *from, HTREE *codeTree)
{
	HTREE *readTree;
	char position[20] = { "./decompress.txt" };
	FILE *read;
	FILE *write;
	read = fopen(from, "r");
	write = fopen(position, "w");
	char readChar=0;
	while (readChar != EOF)
	{
		readTree = codeTree;
		int readNum = 0;
		while ((readChar = getc(read)) != '0')
		{
			if (readChar == EOF)break;
			readNum++;
		}
		if (readChar  == EOF)break;
		for (int i = 1; i <= readNum; i++)
		{
			readTree = readTree->right;
		}
		readTree = readTree->left;
		putc(readTree->item.F, write);
	}
	fclose(read);
	fclose(write);
}