#pragma once
#include<stdlib.h>
#ifndef HFMTREE_H
#define HFMTREE_H
typedef struct hitem
{
	char F;
}HITEM;
typedef struct hfmnode
{
	HITEM item;
	struct hfmnode  *left;
	struct hfmnode  *right;
}HTREE;
void iniHtree(HTREE *H,HITEM in)
{
	H->item = in;
	H->left=NULL;
	H->right = NULL;
}
HTREE * combineNewHtree(HTREE *leftH,HTREE *ringhtH)
{
	HTREE *newTree;
	newTree = (HTREE *)malloc(sizeof(HTREE));
	newTree->item.F = '0';
	newTree->left = leftH;
	newTree->right = ringhtH;
	return newTree;
}

#endif // !HFMTREE_H
