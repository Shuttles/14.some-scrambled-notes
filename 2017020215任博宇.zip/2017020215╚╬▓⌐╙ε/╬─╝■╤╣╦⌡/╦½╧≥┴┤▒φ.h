#include<stdlib.h>
#include<stdbool.h>
#include<stdio.h>
#include"hfmTree.h"
#pragma once
#ifndef LINE
#define	LINE
typedef struct items
{
	HTREE *hfm;
	int weight;
}ITEM;
typedef struct node
{
	struct node *prior;
	struct node *next;
	ITEM item;
}NODE;
typedef struct list
{
	NODE *first;
	NODE *last;
	int listSize;
}LIST;
void iniList(LIST *L)
{
	L->first = NULL;
	L->last = NULL;
	L->listSize = 0;
}
bool emptList(LIST *L)
{
	if (L->listSize == 0)return 1;
	else return 0;
}
int sizeList(LIST *L)
{
	return L->listSize;
}
void addList(LIST*L, ITEM IN)
{
	NODE *evt;
	evt = (NODE *)malloc(sizeof(NODE));
	evt->item = IN;
	if (L->listSize == 0)
	{
		evt->prior = NULL;
		evt->next = NULL;
		L->first = evt;
		L->last = evt;
	}
	else
	{
		evt->prior = L->last;
		evt->next = NULL;
		L->last->next = evt;
		L->last = evt;
	}
	L->listSize++;
}
void insertList(LIST *L, ITEM IN, int indexof)
{
	if (indexof<1 || indexof>L->listSize + 1)
	{
		printf("�޴���Ŀ\n");
		return;
	}
	else if (indexof == L->listSize + 1)
	{
		addList(L, IN);
		return;
	}
	else if (indexof == 1)
	{
		NODE *evt;
		evt = (NODE *)malloc(sizeof(NODE));
		evt->item = IN;
		evt->prior = NULL;
		evt->next = L->first;
		L->first->prior = evt;
		L->first = evt;
		L->listSize++;
	}
	else
	{
		NODE *read;
		read = L->first;
		for (int i = 1; i < L->listSize - 1; i++)
		{
			read = read->next;
		}
		NODE *evt;
		evt = (NODE *)malloc(sizeof(NODE));
		evt->item = IN;
		evt->prior = read;
		evt->next = read->next;
		read->next->prior = evt;
		read->next = evt;
		L->listSize++;
	}
}
void deleteList(LIST *L, int indexof)
{
	void deleteLastList(LIST *L);
	if (indexof<1||indexof>L->listSize)
	{
		printf("�޴���Ŀ,�޷�ɾ��\n");
		return;
	}
	else if (indexof == L->listSize)
	{
		deleteLastList(L);
		return;
	}
	else if (indexof == 1)
	{
		NODE *read;
		read = L->first;
		read->next->prior = NULL;
		L->first = read->next;
		free(read);
		L->listSize--;
		return;
	}
	else
	{
		NODE *read;
		read = L->first;
		for (int i = 1; i < indexof; i++)
		{
			read = read->next;
		}
		read->prior->next = read->next;
		read->next->prior = read->prior;
		free(read);
		L->listSize--;
	}
}
void deleteLastList(LIST *L)
{
	if (L->listSize == 0)
	{
		printf("������,�޷�ɾ��\n");
		return;
	}
	else if (L->listSize == 1)
	{
		free(L->first);
		L->first = NULL;
		L->last = NULL;
		L->listSize = 0;
	}
	else
	{
		NODE *read;
		read = L->last;
		read->prior->next = NULL;
		L->last = read->prior;
		free(read);
		L->listSize--;
	}
}
ITEM itemInList(LIST *L, int indexof)
{
	if (indexof<1 || indexof>L->listSize)
	{
		printf("�޴���Ŀ");
		system("pause");
		exit(0);
	}
	NODE *read;
	read = L->first;
	for (int i = 1; i < indexof; i++)
	{
		read = read->next;
	}
	return read->item;
}
ITEM * itemPtrList(LIST *L, int indexof)
{
	if (indexof<1 || indexof>L->listSize)
	{
		printf("�޴���Ŀ");
		system("pause");
		exit(0);
	}
	NODE *read;
	read = L->first;
	for (int i = 1; i < indexof; i++)
	{
		read = read->next;
	}
	return &read->item;
}
void reviseList(LIST *L, int indexof, ITEM IN)
{

	if (indexof<1 || indexof>L->listSize)
	{
		printf("�޴���Ŀ");
		system("pause");
		exit(0);
	}
	NODE *read;
	read = L->first;
	for (int i = 1; i < indexof; i++)
	{
		read = read->next;
	}
	read->item = IN;
}
void moveList(LIST *L, int from, int to)
{
	if (from > L->listSize || from < 0)
	{
		printf("�޴���Ŀ");
		return;
	}
	if (from > L->listSize || from < 0)
	{
		printf("�޴���Ŀ");
		return;
	}
	if (from == to)return;
	insertList(L, itemInList(L, from), to);
	if (from > to)
	{
		deleteList(L, from + 1);
	}
	else
	{
		deleteList(L, from);
	}
}
void sortList(LIST *L, bool(*sortMethod)(ITEM readItem, ITEM sortItem))
{
	NODE *read;
	NODE *sort;
	read = L->first;
	int readNum;
	readNum = 1;
	while (read)
	{
		sort = L->first;
		int sortNum;
		sortNum = 1;
		while (sort != read)
		{
			if (sortMethod(read->item, sort->item))
			{
				insertList(L, read->item, sortNum);
				readNum++;
				read = read->next;
				deleteList(L, readNum);
				read = read->prior;
				readNum--;
				break;
			}
			sort = sort->next;
			sortNum++;
		}
		read = read->next;
		readNum++;
	}
}
void closeList(LIST *L)
{
	NODE *read;
	read = L->first;
	for (int i = 1; i < L->listSize; i++)
	{
		read = read->next;
		free(read->prior);
	}
	free(read);
	L->first = NULL;
	L->last = NULL;
	L->listSize = 0;
}
#endif