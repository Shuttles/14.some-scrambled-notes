#include"hfmProblem.h"
void main()
{
	HTREE *codeTree;
	txtToTree("./yuanwen.txt");
	treeToCode("./Tree.dat");
	codeTree = codeToTree("./Code.dat");
	treeCompress("./yuanwen.txt",codeTree);
	treeDecompress("./compress.dat", codeTree);
}