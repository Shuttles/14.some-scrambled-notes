#include <stdio.h>
#include <stdlib.h>
#define ERROR 0
#define OK 1
typedef struct Queue {
    int *data;
    int head, tail, length;
}Queue;
void init(Queue *q, int length) {
    q->data = (int *)malloc(sizeof(int) * length);
    q->length = length;
    q->head = 0;
    q->tail = -1;
}
int push(Queue *q, int element) {
    if(q->tail + 1 >= q->length) {
        return ERROR;
    }
    q->tail++;
    q->data[q->tail] = element;
    return OK;
}
void output(Queue *q) {
    int i; 
	for (i = q->head; i <= q->tail; i++) {
        printf("%d ", q->data[i]);
    }
    printf("\n");
}
int front(Queue*q){
    return q->data[q->head];
}
void pop(Queue*q){
    q->head++;
}
int empty(Queue*q){
    return q->head>q->tail;
}
void clear(Queue *q) {
    free(q->data);
    free(q);
}
int main() 
{
	Queue*list=(Queue*)malloc(sizeof(Queue));    
	init(list,5);
	int a,b,c,d,e;
	scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);
	int count=0,k;
	int wt=0,it=0,st=0,sum=0;
	double sumba;
	push(list,a);
	push(list,b);
	push(list,c);
	push(list,d);
	push(list,e);
	for(k=list->head;k<=list->tail;k++)
	{
		it=count;
		st=it+front(list);
		count+=front(list);
		pop(list);
		wt=it; 
		sum+=wt;
		printf("��ʼʱ�䣺%d--����ʱ�䣺%d--�ȴ�ʱ��:%d\n",it,st,wt);
	}
    sumba=sum/5.0;
	printf("ƽ���ȴ�ʱ�䣺%f\n",sumba);
	int x[5],i,j,t;
	x[0]=a,x[1]=b,x[2]=c,x[3]=d,x[4]=e;
	for(j=0;j<4;j++)
	for(i=0;i<4-j;i++)
	if(x[i]>x[i+1])
	{
		t=x[i];x[i]=x[i+1];x[i+1]=t;	
	}
	double g=(x[0]+x[1]+x[2]+x[3]+x[4])/5.0;
	printf("����ƽ���ȴ�ʱ�䣺%f\n",g);
	printf("�������У�");
	for(i=0;i<5;i++)
	{
		printf("%d\n",x[i]);
	}system("pause");
return 0;    
}
