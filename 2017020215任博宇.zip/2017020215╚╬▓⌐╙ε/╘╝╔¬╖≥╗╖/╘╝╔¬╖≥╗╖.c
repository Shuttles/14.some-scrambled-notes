#include <stdio.h>
#include <stdlib.h>
typedef struct person
	{
		int number;
		struct person*next;
	}Node;
Node*creat(int i)
{
	Node*p1,*p2,*head=NULL;
	int n=0;
	p1=p2=(Node*)malloc(sizeof(Node));
	while(n<i)
	{
		n++;
		if(n==1) head=p1,p1->number=n;
		else
		p2->next=p1;
		p2=p1;
		p1=(Node*)malloc(sizeof(Node));
		p1->number=n+1;
	}
	p2->next=head;
	return head;
}
int main(){
	Node*creat(int i);
	int n,m ,tag=0,i;// chu shi hua renshu he mi ma
	printf("������n��m ��ֵ���Կո����"); 
	scanf("%d%d",&n,&m );//shu ru ren shu he m
	Node*p,*q;
	p=q=creat(n);
	if(n==1)
	{ //n==1 chu shu jiedian zhi
		printf("%d\n",p->number);
			}else if(n==0){
			printf("ERROR");
			}else{//n!=1&&n!=0 
			if(m ==1){ //an jie dian shun xu chu shu
			for(tag=0;tag==0;){
				printf("%d\n",p->number);
				p=p->next;
				if(p==q){tag=1;
				}
			}
		}else if(m ==0){
			printf("ERROR");
		}else{  //m!=1&&n!=1 zhu ti 		
			for(;p->next!=q;p=p->next){
			}
			for(i=1;q!=p;i++){
			if(i%m ==0){
			printf("%d\n",q->number);
			p->next=q->next;
			free(q);
		 	q=p->next;
			}
			else{
			q=q->next;
			p=p->next;
				}
			} 
			printf("%d\n",p->number);	
		}
	}
return 0;
} 
