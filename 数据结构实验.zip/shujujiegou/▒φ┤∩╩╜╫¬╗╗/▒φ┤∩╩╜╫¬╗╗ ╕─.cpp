#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 20

typedef int DATA;
typedef struct Stack
{
	DATA data[SIZE];
	int top;
}Stack;


Stack *InitStack()
{
	Stack *p;
	if(p=(Stack *)malloc(sizeof(Stack)))
	  {
	  	p->top=0;
	  	return p;
	  }
	  return NULL;
}

DATA Push(Stack *s,DATA data)
{
	if((s->top+1)>SIZE)
	  {
	  	printf("�����\n");
		return 0; 
	  }
	s->data[++s->top]=data;
	return 1;
} 

DATA Pop(Stack *s)
{
	if(s->top==0)
	  {
	  	printf("ջ�գ�1 \n");
	  	exit(0);
	   }
	return (s->data[s->top--]);
}

DATA PopPeek(Stack *s)
{
	if(s->top==0)
	  {
	  	printf("ջ�գ�2 ");
		exit(0); 
	  }
	return (s->data[s->top]);
}

int Isoper(char a)
{
	switch(a)
	{
		case '+':
		case '-':
		case '*':
		case '/':
		case '(':
		case ')':
		case '=':
			return 1;break;
		default:
			return 0;break;
	}
 } 
 
int Compe(char oper1,char oper2)
{
	int pri;
	switch(oper2)
	{
		case '+':
		case '-':
		       if(oper1=='(' || oper1=='=')
			     pri=-1;
			   else  pri=1;
			   break;
		case '*':
		case '/':
		       if(oper1=='*' || oper1=='/' || oper1==')') 
		         pri=1;
		       else  pri=-1;
		       break;
		case '(':
			   if(oper1==')')
			     {
			     	printf("Error1");
			     	exit(0);
				 }
			   else  pri=-1;
			   break;
	    case ')':
	    	   if(oper1=='(')
	    	     pri=0;
		       else if(oper1=='=')
			     {
			     	printf("Error2");
			     	exit(0);
			     }
			   else  pri=-1;
			   break;
		case '=':
			   if(oper1=='(' )
			     {
			     	printf("Error3");
				 }
			   else if(oper1=='=')
			     pri=0;
			   else  pri=1;
			   break;
	}
	return pri;
}

int calc(int a1,char op,int a2)
{
	switch(op)
	  {
	  	case '+':
	  		return a1+a2;
	  	case '-':
	  		return a1-a2;
	  	case '*':
	  		return a1*a2;
	  	case '/':
		    return a1/a2; 
	  }
}

char MidtoLast(char *Mid)
{
	int length=strlen(Mid);
	int i,top=0,j;
	char *Stack,*Last,*p,flag;
	char op;
	Stack=(char *)malloc(sizeof(char)*length);
	Last=(char *)malloc(sizeof(char)*length);
	p=Last;
	for(i=0;i<length;i++)
	  {
	  	op=Mid[i];
	  	switch(op)
	  	  {
	  	  	case '(':
	  	  		if(top<length)
	  	  		{
	  	  			top++;
	  	  			Stack[top]=op;
				}
				flag=0;break;
			case '+':
			case '-':
			case '*':
			case '/':
				{
					
					switch(Compe(op,Stack[top]))
					   	{
					   		case 1:
							   	*p++=Stack[top];
					   			top--;
					   			flag=0;break;
					   		default:break;
						   }
					if(top<length)
					    {
					    	top++;
					    	Stack[top]=op;
					    	if(flag==1)
					    	  *p++=',';
					    	flag=0;
						}
				}break;
			case ')':
				while(Stack[top]!='(')
				  {
				  	*p++=Stack[top];
				  	top--;
				  }
				flag=0;
				top--;
				break;
			default:
			    *p++=op;
			    flag=1;
			    break;
		    }
	  }
	  
	  while(top>0)
	  {
	  	*p++=Stack[top];
	  	top--;
	  }
	  free(Stack);
	  *p='\0';
	  puts(Last);
	  return 0;
}

char MidtoFront(char *Mid)
{
	int length=strlen(Mid);
	int i,top=0,j;
	char *Stack,*Front,*p,flag;
	char op;
	Stack=(char *)malloc(sizeof(char)*length);
	Front=(char *)malloc(sizeof(char)*length);
	p=Front;
	for(i=length-1;i>=0;i++)
	  {
	  	op=Mid[i];
	  	switch(op)
	  	   {
	  	   	  case ')':
	  	  		if(top<length)
	  	  		{
	  	  			top++;
	  	  			Stack[top]=op;
				}
				flag=0;break;
			  case '+':
			  case '-':
			  case '*':
			  case '/':
				{
					
					switch(Compe(op,Stack[top]))
					   	{
					   		case 1:
							   	*p++=Stack[top];
					   			top--;
					   			flag=0;break;
					   		default:break;
						   }
					if(top<length)
					    {
					    	top++;
					    	Stack[top]=op;
					    	if(flag==1)
					    	  *p++=',';
					    	flag=0;
						}
				}break;
			  case '(':
				while(Stack[top]!=')')
				  {
				  	*p++=Stack[top];
				  	top--;
				  }
				flag=0;
				top--;
				break;
			  default:
			    *p++=op;
			    flag=1;
			    break;
			}
	  }
	  while(top>0)
	  {
	  	*p++=Stack[top];
	  	top--;
	  }
	  free(Stack);
	  *p='\0';
	  puts(Front);
	  return 0;
}

int Result(char Mid[])
{
    Stack *Stackoper,*Stackdata;
    int i=0,flag=0;
    int a,b,q,t,w;
	char c,x,oper;
    Stackoper=InitStack();
    Stackdata=InitStack();
    q=0;
    x='=';
    Push(Stackoper,x);
    c=Mid[i++];
    while(c!='=' || x!='=')
      {
      	if(Isoper(c))
      	 {
      	 	if(flag=1)
      	 	  {
      	 	 	 Push(Stackdata,q);
      	 	 	 q=0;
      	 	 	 flag=0;
				}
			switch(Compe(x,c))
			  {
			  	case -1:
			  		Push(Stackoper,c);
					c=Mid[i++];break;
				case 0:
					Pop(Stackoper);
					c=Mid[i++];break;
				case 1:
					oper=Pop(Stackoper);
					b=Pop(Stackdata);
					a=Pop(Stackdata);
					t=calc(a,oper,b);
					Push(Stackdata,t);
					break;
			  }
		   }
		else if(c>='0' && c<='9')
		  {
		  	c-='0';
		  	q=q*10+c;
		  	flag=1;
		  	c=Mid[i++];
		  }
		else
		  {
			printf("Error4\n");
			getchar();
			exit(0);
		  }
		x=PopPeek(Stackoper);
	  }
	  q=PopPeek(Stackdata);
	  printf("%d\n",q);
	  return 0;
}

int main()
{
	int a;
	char Mid[20];
	printf("��������׺����ʽ��\n");
	gets(Mid);
	system("cls");
	printf("������ϣ����ɵĲ�����\n");
	printf("1.��ֵ 2.ת��׺ 3.תǰ׺\n"); 
	scanf("%d",&a);
	switch(a)
	  {
	  	case 1:
	  		
		    Result(Mid);break;
	  	case 2:MidtoLast(Mid);break;
	  	case 3:break;
	  	default:printf("Error��");break;
	  }
	return 0;
}


