#include<stdio.h>
#include<stdlib.h>
#define MAXNUM 100 

typedef struct Queue
{
	int name;
	int time1;
	int time2;
	struct Queue *next;
}Lnode;

Queue A[MAXNUM];

int Aver_s(Lnode *p)
{
	Lnode *q,*r;
	int wtime=0,etime=0,atime=0,x;
	printf("����  ����CPUʱ��(s) �ȴ�ʱ�� ��ʼʱ�� ����ʱ��\n");
	r=p;
	while(r->next)
     {q=r;
      p=q->next;
      while(p->next)
      { q=q->next;
        p=p->next;
        if(q->time1<p->time1)
         {
		  x=q->name;
          q->name=p->name;
          p->name=x;
          x=q->time1;
          q->time1=p->time1;
          p->time1=x;
         } 
      } 
      printf("  %d  ",p->name);
      printf("%10d",p->time1);
      wtime=etime;
      atime=wtime;
      etime=etime+p->time1;
      printf("%10d",wtime);
      printf("%10d",atime);
      printf("%10d\n",etime);
      q->next=NULL;
     }
}

int Con_time2(Lnode *first)
{
	Lnode *p,*q,*r,*first2;
	int a,b,c;
	printf("�������˳��\n");
	p=(Queue*)malloc(sizeof(struct Queue));
	q=(Queue*)malloc(sizeof(struct Queue));
	r=(Queue*)malloc(sizeof(struct Queue));
	p=first->next;
	c=p->time2;
	first=q;
	while(p)
	  {
	  	q->next=r;
        q=q->next;
        q->next=NULL;
        q->name=p->name;
        q->time1=p->time1;
        q->time2=p->time2;
        r=first2->next;
	  
	    if(r->next->next)
  	 	 {
		   q=r->next;
   		   while(q->next){
   		    	if(r->time1>q->time1)
   		     	 {
			 	  a=r->name;
   		     	  r->name=q->name;
    		  	  q->name=a;
   		  	  	  a=r->time1;
    		  	  r->time1=q->time1;
    		   	  q->time1=a;
  		      	 } 
  		  		q=q->next;
  		  		r=r->next;
  		      }
  		   }
		 if(first2->next->next)
 		{
		 b=p->time2-c;
 		 c=p->time2;
 		 while(b!=0)
 		  {
		   if(b>first2->next->time1)
  		   {
			 b=b-first2->next->time1;
   		     printf(" %d  ",first2->next->name);
  		     printf("\n");
  		     first2->next=first2->next->next;   
   		   }
  		  else 
			{
			if(b<first2->next->time1)
   		      {
				 first2->next->time1=first2->next->time1-b;
   		         b=0;
    		      }
   		      else 
     		    {
				 b=0;
     		     printf(" %d  ",first2->next->name);
     		     printf("\n");
     		     first2->next=first2->next->next;
    		    }  
    		} 
   		   }

 		 }
		 p=p->next;
	  }
		 r=first2->next;
 		 q=r->next;
 		 while(q)
 		 {
 		    if(r->time1>q->time1)
 		     {
			  a=r->name;
 		      r->name=q->name;
 		      q->name=a;
  		      a=r->time1;
  		      r->time1=q->time1;
  		      q->time1=a;
 		      } 
 		  q=q->next;
 		  r=r->next;
 		 }
 		r=first2->next;
		 while(r)
 		{ printf(" %d  ",r->name);
 		  printf("\n");
 		  r=r->next;
 		}
}

int main()
{
	int front,rear;
	int a=0,b=1,n,m,c=0;
	Queue *p,*q,*first;
	p=(Queue*)malloc(sizeof(struct Queue));
	first=p;
	printf("��ѡ��\n 1.�����ύʱ�� 2.����ʱ��\n");
	scanf("%d",&a);
    do
	  {
	  	q=(Queue*)malloc(sizeof(struct Queue));
	    p->next=q;
	    p=p->next;
		printf("������������:");
        scanf("%d",&n);
        p->name=n;
        printf("��������������ʱ��(s):");
        scanf("%d",&m);
        p->time1=m;
        if(a==2)
          {
          	printf("�����������ύʱ��:");
            scanf("%d",&m);
            p->time2=m;
		  }
		else p->time2=0;
		printf("�Ƿ������������0.��  1.��");
		scanf("%d",&b);
	  }while(b!=0);
	p->next=NULL;
	printf("��ѡ��1.������˳��  2.ƽ���ȴ�ʱ�����\n");
	scanf("%d",&c);
	switch(a)
      {
      	case 1:
      		if(c==1)
      		{
      			p=first->next;
                printf("����\t����CPUʱ��(s)\n");
                while(p)
                { 
                   printf("    %d\t",p->name);
                   printf("    %d",p->time1);
                   printf("\n");
                   p=p->next;
			    } 
		      }
		    else Aver_s(first);break;
		case 2:Con_time2(first);break;
		default:break; 
	  }
	return 0;
}
