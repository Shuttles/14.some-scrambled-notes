#include<iostream>
#include <stack>
using namespace std;
#define NUM 4
#define NIL -1

int GetPositionFromLaday(int ladayArray[][NUM], int laday, int man)
{
	for(int i=0; i<NUM; i++)
		if(ladayArray[laday][i] == man)
			return i;
	return NIL;
}

void ChoosePartener(stack<int>& manStack, int manPos, int manArray[][NUM], int ladayArray[][NUM], int manNow[], int manNowPos[], int ladayNow[])
{
		int perferLaday = manArray[manPos][manNowPos[manPos]];
		int oldPos;
		int newPos; 
		if(ladayNow[perferLaday] == NIL)
		{
			ladayNow[perferLaday] = manPos;
			manNow[manPos] = perferLaday;
		}
		else
		{
			oldPos = GetPositionFromLaday(ladayArray, perferLaday, ladayNow[perferLaday]);
			newPos = GetPositionFromLaday(ladayArray, perferLaday, manPos); 
			if(oldPos < newPos)
			{
				manNowPos[manPos]++;
				manStack.push(manPos);
			}
			else
			{
				manNowPos[ladayNow[perferLaday]]++;
				manStack.push(ladayNow[perferLaday]);
				ladayNow[perferLaday] = manPos;
				manNow[manPos] = perferLaday;
			}
		}
}

int main()
{
	int manArray[NUM][NUM] ={{2,1,3,0},{3,1,2,0},{1,2,0,3},{1,3,2,0}};	
	int ladayArray[NUM][NUM] = {{0,2,3,1},{1,3,2,0},{0,3,2,1},{0,1,2,3}}; 
	int manNow[NUM] = {0};
	int manNowPos[NUM] = {0};
	int ladayNow[NUM] = {NIL,NIL,NIL,NIL};
	stack<int> manStack;
	for(int k=0; k<NUM; k++)
	{
		ChoosePartener(manStack,k,manArray,ladayArray,manNow,manNowPos,ladayNow);
	}
	while(manStack.size()!=0)
	{
		int manPos = manStack.top();
		manStack.pop();
		ChoosePartener(manStack,manPos,manArray,ladayArray,manNow,manNowPos,ladayNow);
	}
	for(int i =0;i<NUM; ++i)
		cout<<"��ʿ "<<i+1<<"��Ůʿ "<<manNow[i]+1<<"�ɹ����"<<endl;
}
