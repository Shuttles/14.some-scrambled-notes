#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#define OVERFLOW -2 

typedef struct OLNode{
	int row,col;
	int data;
	struct OLNode *right,*down;
}OLNode,*OLink;

typedef struct{
	OLink *rhead,*chead;
	int mu,nu,tu;
}CrossList;

int CreateSMatrix_OL(CrossList &M)
{
	int i,j,m,n;
	int e,a,b,t;
	OLNode *p,*q;
	
	printf("������Ҫ��������������������Լ�����Ԫ����\n");
	scanf("%d%d%d",&m,&n,&t);
	M.mu=m;
	M.nu=n;
	M.tu=t;
	if(!(M.rhead=(OLink*)malloc((m+1)*sizeof(OLink)))) exit(OVERFLOW);
	if(!(M.chead=(OLink*)malloc((n+1)*sizeof(OLink)))) exit(OVERFLOW);
	for(a=0;a<m+1;a++) M.rhead[a]=NULL;
	for(b=0;b<n+1;b++) M.chead[b]=NULL;
	system("cls");
	printf("�������������Ԫ�ص��С��С�ֵ��\n");
	for(a=1;a<=t;a++)
	{
	    scanf("%d%d%d",&i,&j,&e);
		if(!(p=(OLNode*)malloc(sizeof(OLNode)))) exit(0);
		p->row=i;
		p->col=j;
		p->data=e;
		if(M.rhead[i]==NULL)
		  {
		  	M.rhead[i]=p;
		    p->right=NULL;
		  }
		else
		{
			for(q=M.rhead[i];q->right && q->right->col<j;q=q->right);
			p->right=q->right;
			q->right=p; 
		}
		if(M.chead[j]==NULL)
		  {
		  	M.chead[j]=p;
			p->down=NULL;
		  }
		else
		{
			for(q=M.chead[j];q->down&&q->down->row<i;q=q->down);
			p->down=q->down;
			q->down=p;
		}
		system("cls");
	}
}

int PrintSMatrix_OL(CrossList &M)
{
	OLNode *p;
	int i;
	for(i=1;i<M.mu;i++)
	  {
	  	p=M.rhead[i];
	    while(p!=0)
	    {
	      printf("(%d,%d) %d\n",p->row,p->col,p->data);
	  	  p=p->right;
	    }
	  }
	  
}

int main()
{
	CrossList M;
	CreateSMatrix_OL(M);
	PrintSMatrix_OL(M);
	return 0;
} 
