#include<stdio.h>
#include<malloc.h>
#include<string.h>
#define MAXSIZE 100


typedef char datatype;
typedef enum{ATOM,LIST}Elemtag;
typedef struct node
{
    int tag;
    union
    {
        datatype data;
        struct
        {
            struct node *hp , *tp;
        }ptr;
    };
}GLNode,*GList;

void substr(char *s,char *sub,int startIndex,int len)
{
   int i;
   for(i=1;i<startIndex;s++,i++) ;
   for(i=0;i<len ; i++)
   {
       sub[i]=s[i];
   }
   sub[len]='\0';
}

void server(char *hsub,char *s)
{
   int i,k;
   for(i = 0,k = 0;i<strlen(s);i++)
   {
       if(s[i] == '(')
       {
           k++;
       }
       if(s[i] == ')')
       {
           k--;
       }
       if(s[i]==',' && k==0)
       {
           break ;
       }
   }
   if(i < strlen(s))
   {
       substr(s,hsub,1,i);
       substr(s,s,i+2,strlen(s)-i-1);
   }
   else
   {
       substr(s , hsub , 1 ,strlen(s));
       s[0]='\0';
   }
}


int CreateGList(GList *ls, char *s)
{
    GLNode *p,*q;
    char hsub[MAXSIZE];
    if(s==NULL)
    {
        *ls=NULL;
    }
    else
    {
        if(!(*ls=(GList)malloc(sizeof(GLNode))))
        {
            return 0;
        }
        if(strlen(s)==1)
        {
            (*ls)->tag=0;
            (*ls)->data=*s;
        }
        else
        {
            substr(s , s , 2 , strlen(s)-2);
            p = (*ls) ;
            p->tag = 1 ;
            do
            {
                server(hsub , s) ;
                CreateGList(&(p->ptr.hp),hsub);
                q = p;
                if(*s != '\0')
                {
                    p = (GList)malloc(sizeof(GLNode));
                    p->tag = 1;
                    q->ptr.tp = p;
                }
                else
                {
                    p->ptr.tp = NULL;
                }
            }while(*s != '\0');
        }
    }
    return 1;
}

void printGList(GList ls)
{
    if(ls != NULL)
    {
        if(ls->tag == 0)
        {
            printf("%c " , ls->data);
        }
        else
        {
            printGList(ls->ptr.hp);
            printGList(ls->ptr.tp);
        }
    }
}

int Merge(GList l1, GList l2, GList *ls)
{
    if(!((*ls) = (GList)malloc(sizeof(GLNode))))
    {
        return 0;
    }
    (*ls)->tag=1;
    (*ls)->ptr.hp=l1;
    (*ls)->ptr.tp=l2;
    return 1 ;
}

int Depth(GList ls)
{
    GList p;
    int max,depth;
    if(ls==NULL)
    {
        return 1;
    }
    if(ls->tag==0)
    {
        return 0;
    }
    for(max=0,p=ls->ptr.tp;p;p=p->ptr.tp)
    {
        depth=Depth(p); 
        if(depth>max)
        {
            max=depth;
        }
    }
    return max+1;
}

int CopyGList(GList ls , GList *ls1)
{
    if(ls == NULL)
    {
        (*ls1) = NULL ;
    }
    else
    {
        if(!((*ls1)=(GList)malloc(sizeof(GLNode))))
        {
            return 0 ;
        }
        if(ls->tag == 0)
        {
            (*ls1)->tag = 0 ;
            (*ls1)->data = ls->data ;
        }
        else
        {
            (*ls1)->tag = 1 ;
            CopyGList(ls->ptr.hp , &((*ls1)->ptr.hp)) ;
            CopyGList(ls->ptr.tp , &((*ls1)->ptr.tp)) ;
        }
    }
}

GList GetHead(GList ls)
{
    GList list=NULL;
    if(ls->tag==1)
    {
        list=ls->ptr.hp;
    }
    return list;
}

GList GetTail(GList ls)
{
    GList list=NULL;
    if(ls->tag==1)
    {
        list=ls->ptr.tp;
    }
    return list ;
}

int main()
{
  GList ls1,ls2,ls3,ls4;
  char s[MAXSIZE],s1[MAXSIZE]; 
  scanf("%s",s);
  CreateGList(&ls1,s);
  scanf("%s",s1);
  CreateGList(&ls2,s1);
  printGList(ls1);
  printf("\n");
  printGList(ls2);
  printf("\n");
  printf("��һ���Ϊ%d\n",Depth(ls1));
  printf("�������Ϊ%d\n",Depth(ls2));
  Merge(ls1,ls2,&ls3);
  printGList(ls3);
  printf("\n");
  printf("�������Ϊ%d\n����Ϊ",Depth(ls3));
  CopyGList(ls3,&ls4);
  printGList(ls4);
  return 0;
}

