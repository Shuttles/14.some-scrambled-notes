#include<cstring>
#include<iostream>
#include<stdio.h>
using namespace std;
struct student{
	char name[40];
	int number;
	int Class;
	char Major[50];
	char Grade[10];
	char Honour[100];
};

class votesystem{
private:
	student *stu;
	int count;
	int sizeindex;
public:
	votesystem() {stu=NULL;count=0;sizeindex=0;}
	~votesystem() {delete []stu;count=0;}
	void InitHashTable(int n);
	int Hash(char *name);	
	void deal(int &s) {s=s++;}		//���Ŷ�ַ
	int search(char *name,int &k);
	void insert(char*name);		
	int vote(char*name);		
	void display();		
	void showvote(int k); 	
	void showrank();	
};


void votesystem::InitHashTable(int n){
	sizeindex=n;
	stu=new student[sizeindex];
	for(int i=0;i<sizeindex;i++)
		stu[i].name[0]='\0';
}

int votesystem::Hash(char *name){
	char *p=name;
	int key=0;
	while(*p)
	{
		key+=int(*p);
		p++;
	}
	return key%sizeindex;
}

int votesystem::search(char *name,int &k){

	k=Hash(name);
	while(stu[k].name[0]!='\0'&&strcmp(stu[k].name,name))
	       deal(k);
	if(!strcmp(stu[k].name,name)) return 1;
	else return 0;
}

void votesystem::insert(char *name){
	int s;
	char a[2];
	search(name,s);
	cout<<"������ʽ���£�\n"
		<<"\t�༶��20162016\n"
		<<"\tרҵ����������\n"
		<<"\t�꼶�����\n"
        <<"\tͻ���¼�������ѧ��\n";
	strcpy(stu[s].name,name);
	cout<<"�༶��\t";cin>>stu[s].Class;
	cout<<"רҵ��\t";cin.getline(a,2);cin.getline(stu[s].Major,50);
	cout<<"�꼶��\t";cin.getline(stu[s].Grade,10);
    cout<<"ͻ���¼���\t";cin.getline(stu[s].Honour,100);
	stu[s].number=1; 
	count++;
}

int votesystem::vote(char*name){
	int s;
	int f;
	f=search(name,s);
	if(f) {stu[s].number++;return 1;}
	else return 0;
}

void votesystem::display(){
	for(int i=0;i<sizeindex;i++)
		{
			if(stu[i].name[0]!='\0')
				cout<<stu[i].name<<' '
					<<stu[i].number<<"Ʊ��"<<' '
                	<<stu[i].Major<<' ' 
           		 	<<stu[i].Grade
            	    <<stu[i].Class<<"�༶"<<' '
                	<<stu[i].Honour<<'\t'
					<<endl;
			else{
				cout<<"����ͶƱ\n";
				break;
			} 
		 } 
}

void votesystem::showvote(int k){
	cout<<"Ʊ����"<<stu[k].number;
}

void votesystem::showrank(){
	int i,k;
	int a[11];
	for(int i=0;i<10;i++) a[i]=-1;
    for( i=0;i<sizeindex;i++)
	{
		if(stu[i].name[0]!='\0')
		{
			for(k=9;k>=0;k--)
			{
				if(a[k]>-1)
				{
					if(stu[a[k]].number<stu[i].number)
						a[k+1]=a[k];
					else break;
				}
			}
		   a[k+1]=i;
		}
	}
	for(i=0;i<10&&a[i]>-1;i++)
	        cout<<stu[a[i]].name<<'\t'
				<<stu[a[i]].number
				<<endl;
}

int main(void){
	int c=-1,k=-1;
	char name[40];
	votesystem L;
	L.InitHashTable(50);
	while(c!=5)
	{
		cout<<"_____________________________________________________\n"
			<<"                     ͶƱϵͳ\n"
			<<"                1��ѡ����Ϣ    \n"
		    <<"                2��ѡ�ֵ�Ʊ��  \n"
		    <<"                3��ͶƱ        \n"
			<<"                4�����а�      \n"
	        <<"                5���˳�ϵͳ    \n"
			<<"_____________________________________________________\n"
			<<"��ѡ�������";
	    cin>>c;
    	switch(c)
		{
			char a[2];
		case 1:
			L.display();break;
		case 2:
			cout<<"������ѡ������+ѧ��(�磺С�� 2016201613)��"<<endl;
			cin.getline(a,2);
			cin.getline(name,40);
			int f;
			f=L.search(name,k);
			if(f) L.showvote(k),cout<<endl;
			else cout<<"�޴˼�¼,����ͶƱ\n";
			break;
		case 3:
            cout<<"������ѡ������+ѧ��(�磺С�� 2016201613)��"<<endl;
			cin.getline(a,2);
			cin.getline(name,40);
			f=L.search(name,k);
			if(f) {L.vote(name);cout<<"ͶƱ�ɹ�\n";}
			else
			{
				cout<<"�޴˼�¼!\n";
				cout<<"     1������\n"
					<<"     2������\n"
					<<"��ѡ�������";
				int t;
				cin>>t;
				if(t==1)
				{
					L.insert(name);
					cout<<"�����ɹ�\n";
				}
			}
			break;
		case 4:
			L.showrank();
			break;
		case 5:
			cout<<"ϵͳ�ѹر�!\n";
			break;
		default:
			cout<<"������Ч��������ѡ��!\n";
			break;
		}
	}
		return 0;
}
