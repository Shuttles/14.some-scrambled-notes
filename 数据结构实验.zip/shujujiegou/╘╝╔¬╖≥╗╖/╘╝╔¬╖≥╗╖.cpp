#include<stdio.h>
#include<stdlib.h>
struct Node
{
	int data;
	Node *next;
};


Node *p,*q,*first;


int creat_list(int n)
{
	first=(Node*)malloc(sizeof(struct Node));
	p=first;
	first->data=1; 
	first->next=NULL;
	int i;
	for(i=2;i<=n;i++)
	  {
	    q=(Node*)malloc(sizeof(Node));
	  	q->data=i;
		p->next=q;
		q->next=NULL;
		p=q;	                                
	   }
	p->next=first;
}


int out_list(int n,int m)
{
	int i;
	while(n)
	{
		for(i=1;i<=m;i++)
		{
			p=q;
			q=q->next;
		 } 
		printf("%4d",q->data);
		p->next=q->next;
		n--;
	}
}


int main()
{
	int n,m;
	printf("�밴��������ʽ����ѧ����n������m��\n");
	scanf("%d %d",&n,&m);
	if(n<1||m<1)printf("Error!");
	else if(n==1) printf("���ӵ��ǣ�1"); 
	else
	{
	creat_list(n);
	printf("���ӵ������ǣ�\n");
	out_list(n,m);
    }
	return 0;
}
