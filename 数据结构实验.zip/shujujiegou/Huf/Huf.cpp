#include<stdlib.h>
#include<stdio.h>
#include<string.h>

typedef struct{
	int weight;
	int parent,lchild,rchild;
}HufTree;
typedef char *HufCode;

void Select(HufTree *T,int n,int *bt1,int *bt2);
void CreateTree(HufTree *T,int n,int *w)
{
	int i,m=2*n-1;
	int bt1,bt2;
	if(n<=1) return ;
	for(i=1;i<=n;++i)
	{
		T[i].weight=w[i-1];
		T[i].parent=0;
		T[i].lchild=0;
		T[i].rchild=0;
	}
	for(;i<=m;++i)
	{
		T[i].weight=0;
		T[i].parent=0;
		T[i].lchild=0;
		T[i].rchild=0;
	}
	for(i=n+1;i<=m;++i)
	{
		Select(T,i-1,&bt1,&bt2);
		T[bt1].parent=i;
		T[bt2].parent=i;
		T[i].lchild=bt1;
		T[i].rchild=bt2;
		T[i].weight=T[bt1].weight+T[bt2].weight; 
	}
}

void Select(HufTree *T,int n,int *bt1,int *bt2)
{
	int i;
	HufTree *ht1,*ht2,*t;
	ht1=ht2=NULL;
	for(i=1;i<=n;++i)
	{
		if(!T[i].parent)
		{
			if(ht1==NULL)
			{
				ht1=T+i;
				continue;
			}
			if(ht2==NULL)
			{
				ht2=T+i;
				if(ht1->weight>ht2->weight)
				{
					t=ht2;
					ht2=ht1;
					ht1=t;
				} 
				continue;
			}
			if(ht1&&ht2)
			{
				if(T[i].weight<=ht1->weight)
				{
					ht2=ht1;
					ht1=T+i;
				}
				else if(T[i].weight<ht2->weight)
				{
					ht2=T+i;
				}
			}
		}
	}
	if(ht1>ht2)				 
	{
		*bt2=ht1-T;
		*bt1=ht2-T;
	}
	else
	{
		*bt1=ht1-T;
		*bt2=ht2-T;
	}
}

void HufCoding(HufTree *T,int n,HufCode *C)
{
	char *a;
	int i,k;
	int parent,current;
	a=(char*)malloc(sizeof(char)*n);
	a[n-1]='\0';
	for(i=1;i<=n;i++)
	{
		k=n-1;
		current=i;
		parent=T[current].parent;
		while(parent){
			if(current==T[parent].lchild)
				a[--k]='0';
			else
				a[--k]='1';
			current=parent;
			parent=T[parent].parent;
		}
		C[i-1]=(char*)malloc(sizeof(char)*(n-k));
		strcpy(C[i-1],&a[k]);
	}
	free(a);
}

void Encode(HufCode *C,char *alp,char *str,char *code1)
{
	int len=0,i=0,j;
	code1[0]='\0';
	while(str[i]){
		j=0;
		while(alp[j]!=str[i]) j++;
		strcpy(code1+len,C[j]);
		len=len+strlen(C[j]);
		i++;
	}
	code1[len]='\0';
}


int main()
{
	int i,n=4,m;
	char test[]="ACDADBACDDCBAD";
	char code1[100],code2[100];
	char alp[]={'A','B','C','D'};
	int w[]={4,2,3,5};
	HufTree *T;
	HufCode *C;
	m=2*n-1;
	T=(HufTree *)malloc((m+1)*sizeof(HufTree));
	C=(HufCode *)malloc(n*sizeof(char*));
	if(!T)
	{
		printf("�ڴ����ʧ��\n");
		exit(0);
	}
	if(!C)
	{
		printf("�ڴ����ʧ��\n");
		exit(0);
	}
	CreateTree(T,n,w);
	HufCoding(T,n,C);
	for(i=1;i<=n;i++)
		printf("�ַ�:%c,Ȩ��:%d,����Ϊ%s\n",alp[i-1],T[i].weight,C[i-1]);
	Encode(C,alp,test,code1);
	printf("\n����:\nת��ǰ:\n%s\nת����:\n%s\n",test,code1);
	return 0;
} 
