#include<stdio.h>
#include<stdlib.h>
typedef struct Node{
	int data;
	Node *next;
}; 


Node *q,*p,*L; 

int creat_linklist(int n)
{   
	L=(Node*)malloc(sizeof(Node));
	p=L;
	p->data=1;
	L->next=NULL;
  int i;
  for(i=2;i<n+1;i++)
  {
     q=(struct Node*)malloc(sizeof(struct Node));
     q->data=i;
     p->next=q;
     p=q;
     q->next=NULL;
  }
    q->next=L;
}        

 int outList(int m,int n)    
{
   int i;
   while(n)
  { for(i=1;i<m;i++)         
      q=q->next;
      printf("%d ",q->next->data);    
          q->next=q->next->next;
      n--; 
		}   
}
 
int main()
{   int m,n;  
    printf("\n������ ����m �� ����n: \n");
    scanf("%d %d",&m,&n);
    if(n<0||m<0)  
       printf("error,����������\n");
	   else
	   {
	   	 creat_linklist( (int) n);  
          
          printf("\n���ӵ���������:\n");
          outList( m,n);
	   }
         
	system("pause");
}
