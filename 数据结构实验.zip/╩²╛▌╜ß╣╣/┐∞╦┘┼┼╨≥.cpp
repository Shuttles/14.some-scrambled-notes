#include <iostream>
#include <stdio.h>
using namespace std;
int z;
#define MaxSize 20
typedef int KeyType;
typedef char InfoType[10];
typedef struct
{
    KeyType key;
    InfoType data;
} RecType;
void QuickSort(RecType R[],int s,int t)
{
    int i=s,j=t;

    RecType tmp;
    if (s<t)
    {
        tmp=R[s];
        while (i!=j)
        {
            while (j>i && R[j].key>=tmp.key)
                j--;
            R[i]=R[j];
            while (i<j && R[i].key<=tmp.key)
                i++;
            R[j]=R[i];
        }
        R[i]=tmp;
for (int x=0; x<z; x++)
        printf("%d ",R[x].key);
        cout << endl;
        QuickSort(R,s,i-1);
        QuickSort(R,i+1,t);
    }
}
int main()
{
    int i,n=0;
    RecType R[MaxSize];
    KeyType a[256];//= {6,8,7,9,0,1,3,2,4,5};
     printf("���������������(�Է�����Ԫ�ؽ���)��\n");
    while(scanf("%d",&a[i])){
    	fflush(stdin);

    //	 printf("\n");
    	n++;
    	i++;
	}
	z = n;
    for (i=0; i<n; i++)
        R[i].key=a[i];
    printf("����ǰ:");
    for (i=0; i<n; i++)
        printf("%d ",R[i].key);
      cout << endl;

    QuickSort(R,0,n-1);
    //printf("�����:");
	//for (i=0; i<n; i++)
        //printf("%d ",R[i].key);
    printf("\n");
    return 0;
	//system("pause");
}

