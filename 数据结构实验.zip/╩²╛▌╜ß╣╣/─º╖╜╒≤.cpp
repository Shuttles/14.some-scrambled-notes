#include<stdio.h>
#include<stdlib.h>
#define max 100
int main()
{
	int a[max][max]={0};
	int i,j,m,y;
	int x=1;
	
	 while(1)
	 {
	 printf("������ħ�������(����)��");
	 scanf("%d",&m);
	 if(m%2==0||m<0)
	 {
	 	printf("����������ħ�������:");
	 	continue;
		 }	
		 else break;
	 }
	 a[1][(m+1)/2]=1;
	 y=(m+1)/2;
	 for(i=2;i<=m*m;i++)
	 {
	 	if(x-1>0&&y-1>0)
	 	{
		 
	 	x=x-1;y=y-1;
	 	if(a[x][y]==0)
	 	{
	 		a[x][y]=i;
		 }
		 else
		 {
		 	x=(x+2)%m;
		 	y=(y+1)%m;
		 	if(x==0)  x=x+m;
		 	if(y==0)  y=y+m;
		 	a[x][y]=i;
		 }
		 continue;
        }
	 if(x-1<=0&&y-1>0)
	 {
	 	x=x-1+m;
	 	y=y-1;
	 	if(a[x][y]==0)
	 	{
	 		a[x][y]=i;
		 }
		 else
		 {
		    x=(x+2)%m;
		 	y=(y+1)%m;
		 	if(x==0)  x=x+m;
		 	if(y==0)  y=y+m;
		 	a[x][y]=i;	
		 }
		 continue;
	 }
	 if(x-1>0&&y-1<=0)
	 {
	 	x=x-1;y=y-1+m;
	 	if(a[x][y]==0)
	 	{
	 		a[x][y]=i;
		 }
		 else
		 {
		 
		    x=(x+2)%m;
		 	y=(y+1)%m;
		 	if(x==0)  x=x+m;
		 	if(y==0)  y=y+m;
		 	a[x][y]=i;	
		 }
		 continue;	
		 
	 }
	 if(x-1<=0&&y-1<=0)
	 {
	 	x=x-1;y=y-1;
	 	if(a[x][y]==0)
	 	{
	 		a[x][y]=i;
		 }
		 else
		 {
		 x=(x+2)%m;
		 	y=(y+1)%m;
		 	if(x==0)  x=x+m;
		 	if(y==0)  y=y+m;
		 	a[x][y]=i;	
		 }
		 continue;
	 }
}
for(i=1;i<=m;i++)
{
	for(j=1;j<=m;j++)
    {
    	printf("%4d ",a[i][j]); 
	}
	printf("\n");
}
system("pause");
return 0;
 } 
