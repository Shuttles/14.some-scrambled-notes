#include<stdio.h>
#include<stdlib.h> 
#include<string.h>
typedef struct
{
	int weight;
	int parent,lchild,rchild;
}HuffmanTree;
typedef char *HuffmanCode;
void SelectNode(HuffmanTree *HT,int n,int *bt1,int *bt2);
void CreateTree(HuffmanTree *HT,int n,int *w)
{
	int i,m=2*n-1;
	int bt1,bt2;
	if(n<=1) return ;
	for(i=1;i<=n;++i)				//��ʼ��Ҷ�ڵ� 
	{
		HT[i].weight=w[i-1];
		HT[i].parent=0;
		HT[i].lchild=0;
		HT[i].rchild=0; 
	}
	for(;i<=m;++i)					//��ʼ������ڵ� 
	{
		HT[i].weight=0;
		HT[i].parent=0;
		HT[i].lchild=0;
		HT[i].rchild=0;
	}
	for(i=n+1;i<=m;++i)					//������������ 
	{
		SelectNode(HT,i-1,&bt1,&bt2);
		HT[bt1].parent=i;
		HT[bt2].parent=i;
		HT[i].lchild=bt1;
		HT[i].rchild=bt2;
		HT[i].weight=HT[bt1].weight+HT[bt2].weight;
	}
}
void SelectNode(HuffmanTree *HT,int n,int *bt1,int *bt2)
{
	int i;
	HuffmanTree *ht1,*ht2,*t;
	ht1=ht2=NULL;
	for(i=1;i<=n;++i)				//��ѡ��Ȩ����С�������ڵ� 
	{
		if(!HT[i].parent)
		{
			if(ht1==NULL)
			{
				ht1=HT+i;
				continue;
			}
			if(ht2==NULL)
			{
				ht2=HT+i;
				if(ht1->weight>ht2->weight)
				{
					t=ht2;
					ht2=ht1;
					ht1=t;
				} 
				continue;
			}
			if(ht1&&ht2)
			{
				if(HT[i].weight<=ht1->weight)
				{
					ht2=ht1;
					ht1=HT+i;
				}
				else if(HT[i].weight<ht2->weight)
				{
					ht2=HT+i;
				}
			}
		}
	}
	if(ht1>ht2)				 
	{
		*bt2=ht1-HT;
		*bt1=ht2-HT;
	}
	else
	{
		*bt1=ht1-HT;
		*bt2=ht2-HT;
	}
}
void HuffmanCoding(HuffmanTree *HT,int n,HuffmanCode *HC)
{
	char *cd;
	int start,i;
	int current,parent;
	cd=(char*)malloc(sizeof(char)*n);
	cd[n-1]='\0';
	for(i=1;i<=n;i++)					//Ϊ������������ 
	{
		start=n-1;
		current=i;
		parent=HT[current].parent;
		while(parent)
		{
			if(current==HT[parent].lchild)
			cd[--start]='0';
			else
			cd[--start]='1';
			current=parent;
			parent=HT[parent].parent;
		}
		HC[i-1]=(char*)malloc(sizeof(char)*(n-start));
		strcpy(HC[i-1],&cd[start]);
	}
	free(cd);
}
void Encode(HuffmanCode *HC,char *alphabet,char *str,char *code)	//�Ƚ������ַ��ҵ����� 
{
	int len=0,i=0,j;
	code[0]='\0';
	while(str[i])
	{
		j=0;
		while(alphabet[j]!=str[i])
		j++;
		strcpy(code+len,HC[j]);
		len=len+strlen(HC[j]);
		i++;
	}
	code[len]='\0';
}
int main()
{
	int i,n=4,m;
	char test[]="ABCDACDB";
	char code[100],code1[100];
	char alphabet[]={'A','B','C','D'};
	int w[]={4,3,2,1};
	HuffmanTree *HT;
	HuffmanCode *HC;
	m=2*n-1;
	HT=(HuffmanTree*)malloc((m+1)*sizeof(HuffmanTree));
	if(!HT)
	{
		printf("�ڴ����ʧ��\n");
		exit(0);
	}
	HC=(HuffmanCode*)malloc(n*sizeof(char*));
	if(!HC)
	{
		printf("�ڴ����ʧ��\n");
		exit(0);
	}
	CreateTree(HT,n,w);
	HuffmanCoding(HT,n,HC);
	for(i=1;i<=n;i++)
	printf("��ĸ:%c,����Ϊ %s\n",alphabet[i-1],HC[i-1]);
	Encode(HC,alphabet,test,code);
	printf("\n�ַ�����\n%s\nת����Ϊ��\n%s\n",test,code);
	return 0; 
}
