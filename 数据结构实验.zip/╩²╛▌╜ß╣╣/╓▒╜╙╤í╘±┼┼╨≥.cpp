#include <stdio.h>
#define MaxSize 20
typedef int KeyType;
typedef char InfoType[10];
typedef struct
{
    KeyType key;
    InfoType data;
} RecType;
void SelectSort(RecType R[],int n)
{
    int i,j,k,l;
    RecType temp;
    for (i=0; i<n-1; i++)
    {
        k=i;
        for (j=i+1; j<n; j++)
            if (R[j].key<R[k].key)
                k=j;
        if (k!=i)               //����R[i]��R[k]
        {
            temp=R[i];
            R[i]=R[k];
            R[k]=temp;
        }
        printf("��%d������:      ",i);
        for (l=0; l<n; l++)
            printf("%d ",R[l].key);
        printf("\n");
    }
}
int main()
{
    int i=0,n=0;
    RecType R[MaxSize];
    KeyType a[256];
    
    printf("���������������(�Է�����Ԫ�ؽ���)��\n");
    while(scanf("%d",&a[i])){
    	fflush(stdin);
    //	 printf("\n");
    	n++;
    	i++;
	}
    for (i=0; i<n; i++)
        R[i].key=a[i];
    printf("����ǰ:         ");
    for (i=0; i<n; i++)
        printf("%d ",R[i].key);
    printf("\n");
    SelectSort(R,n);
    printf("�����:         ");
    for (i=0; i<n; i++)
        printf("%d ",R[i].key);
    printf("\n");
   return 0;
}
