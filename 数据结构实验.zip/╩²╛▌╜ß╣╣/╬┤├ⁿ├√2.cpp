#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#define MAXSIZE 20
typedef int Status;
typedef char ElemType;
typedef struct {
 ElemType data[MAXSIZE];
 int top;//ջ��ָ��
}Stack;
//1.?��ʼ��??
Status InitStack(Stack *S){
 int i;
 for(i=0;i<MAXSIZE;i++)
 S->data[i]=NULL;
 S->top=-1;
 return OK;
}
